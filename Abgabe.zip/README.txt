Die Kompilierung und Ausführung des Programmes erfolgt wie folgt:
cd Clog
javac src/gui/MainWindow.java -cp ./src/
cd src
java gui.MainWindow